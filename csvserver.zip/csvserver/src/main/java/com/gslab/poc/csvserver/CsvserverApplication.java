package com.gslab.poc.csvserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CsvserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(CsvserverApplication.class, args);
	}
}
